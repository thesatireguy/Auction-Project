const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  description: { type: String, required: true, trim: true },
  price: { type: Number, required: true, min: 0 },
  condition: {
    type: String,
    enum: ['new', 'old', 'refurbished'],
    required: true
  },
  imageUrl: { // ✅ Single image URL as string
    type: String,
    required: true,
    trim: true
  },
  seller_name: {
    type: String,
    required: true,
    trim: true
  },
  datePosted: { type: Date, default: Date.now },
  approved: { type: Boolean, default: false }
});

module.exports = mongoose.model('Product', productSchema);
