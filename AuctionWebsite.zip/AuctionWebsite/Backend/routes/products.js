const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Product = require('../models/Product');

// Multer config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(__dirname, '../uploads');
    if (!fs.existsSync(uploadPath)) fs.mkdirSync(uploadPath);
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname.replace(/\s+/g, '_'));
  }
});
const upload = multer({ storage });

// POST /api/products
router.post('/', upload.single('image'), async (req, res) => {
  try {
    const { title, description, price, condition, seller_name } = req.body;

    if (!title || !description || !price || !condition || !seller_name || !req.file) {
      return res.status(400).json({ message: 'All fields including seller name and image are required.' });
    }

    const imageUrl = `/uploads/${req.file.filename}`; // ✅ Single image path

    const newProduct = new Product({
      title,
      description,
      price,
      condition,
      imageUrl, // ✅ Use a single field instead of 'images'
      seller_name,
      approved: false
    });

    await newProduct.save();
    res.status(201).json({ message: 'Product uploaded successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error while uploading product.' });
  }
});
router.get('/', async (req, res) => {
  try {
    const { seller_name } = req.query;

    const filter = {};
    if (seller_name) {
      filter.seller_name = seller_name;
    }

    console.log('Filtering by seller_name:', filter); // ✅ DEBUG LOG

    const products = await Product.find(filter);
    res.json(products);
  } catch (err) {
    console.error('Error fetching products:', err);
    res.status(500).json({ message: 'Failed to fetch products' });
  }
});


router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Product.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: 'Not found' });
    res.json({ message: 'Deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Error deleting product' });
  }
});
router.put('/:id', async (req, res) => {
  try {
    const updated = await Product.findByIdAndUpdate(
      req.params.id,
      { $set: req.body },
      { new: true }
    );
    if (!updated) return res.status(404).json({ message: 'Not found' });
    res.json({ message: 'Updated successfully', product: updated });
  } catch (err) {
    res.status(500).json({ message: 'Error updating product' });
  }
});

// UPDATE product (approve/edit)
router.put('/:id', async (req, res) => {
  try {
    const updateData = {};
    if (req.body.price !== undefined) updateData.price = req.body.price;
    if (req.body.title !== undefined) updateData.title = req.body.title;
    if (req.body.condition !== undefined) updateData.condition = req.body.condition;
    if (req.body.approved !== undefined) updateData.approved = req.body.approved;

    const product = await Product.findByIdAndUpdate(req.params.id, updateData, { new: true });
    if (!product) return res.status(404).json({ message: 'Product not found' });

    res.json(product);
  } catch (error) {
    console.error('Error updating product:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});
router.get('/approved', async (req, res) => {
  try {
    const approvedProducts = await Product.find({ approved: true });
    res.json(approvedProducts);
  } catch (err) {
    console.error('Error fetching approved products:', err);
    res.status(500).json({ message: 'Server error' });
  }
});



module.exports = router;
