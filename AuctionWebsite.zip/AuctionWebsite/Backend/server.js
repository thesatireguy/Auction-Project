// server/server.js

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');
const multer = require('multer');
const fs = require('fs');

dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB connected'))
.catch(err => console.error('❌ MongoDB connection error:', err));

/* ------------------ Models ------------------ */

// User model
const userSchema = new mongoose.Schema({
  first_name: { type: String, required: true },
  last_name:  { type: String, required: true },
  username:   { type: String, required: true, unique: true },
  email:      { type: String, required: true, unique: true },
  password:   { type: String, required: true },
  gender:     { type: String, enum: ['Male', 'Female', 'Other'], required: true },
  city:       { type: String, required: true },
  state:      { type: String, required: true },
  country:    { type: String, required: true },
  phone:      { type: String, required: true },
  registration_date: { type: Date, default: Date.now }
});

const User = mongoose.model('User', userSchema);

/* ------------------ Routes ------------------ */

// Register
// Register Route
app.post('/api/register', async (req, res) => {
  const {
    first_name,
    last_name,
    username,
    email,
    password,
    gender,
    city,
    state,
    country,
    phone
  } = req.body;

  if (
    !first_name || !last_name || !username || !email || !password ||
    !gender || !city || !state || !country || !phone
  ) {
    return res.status(400).json({ message: 'All fields are required.' });
  }

  try {
    const exists = await User.findOne({ $or: [{ username }, { email }] });
    if (exists) {
      return res.status(409).json({ message: 'Username or email already exists.' });
    }

    const newUser = new User({
      first_name,
      last_name,
      username,
      email,
      password, 
      gender,
      city,
      state,
      country,
      phone
    });

    await newUser.save();
    res.status(201).json({ message: 'User registered successfully.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error.' });
  }
});
const productRoutes = require('./routes/products');
app.use('/api/products', productRoutes);

const userRoutes = require('./routes/auth');
app.use('/api', userRoutes); 

// Login
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required.' });
  }

  try {
    const user = await User.findOne({ email });
    if (!user || user.password !== password) {
      return res.status(401).json({ message: 'Invalid email or password.' });
    }

    res.status(200).json({
      message: 'Login successful.',
      user: {
        id: user._id,
        username: user.username,
        email: user.email
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error.' });
  }
});
// Get user by username
app.get('/api/user/:username', async (req, res) => {
  try {
    const { username } = req.params;
    const user = await User.findOne({ username });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.status(200).json({
      first_name: user.first_name,
      last_name: user.last_name,
      username: user.username,
      email: user.email,
      phone: user.phone,
      city: user.city,
      state: user.state,
      country: user.country,
      gender: user.gender,
      registration_date: user.registration_date
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});



/* ------------------ Server ------------------ */

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
