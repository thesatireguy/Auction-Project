document.getElementById('adminLoginForm').addEventListener('submit', (e) => {
    e.preventDefault();
  
    const username = document.getElementById('adminUsername').value.trim();
    const password = document.getElementById('adminPassword').value;
  
    if (username === 'AnmolSrivas' && password === '@Sceptile789') {
      localStorage.setItem('adminLoggedIn', 'true');
      alert('Login successful!');
      window.location.href = 'admin.html';
    } else {
      alert('Invalid admin credentials.');
    }
  });
  