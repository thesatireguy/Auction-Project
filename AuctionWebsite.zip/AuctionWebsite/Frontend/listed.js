window.addEventListener('DOMContentLoaded', async () => {
  const grid = document.getElementById('productGrid');
  if (!grid) return;

  try {
    const userObj = JSON.parse(localStorage.getItem('user'));
    const username = userObj?.username;
    if (!username) throw new Error('User not in localStorage');

    const res = await fetch(`http://localhost:3000/api/products?seller_name=${encodeURIComponent(username)}`);
    if (!res.ok) throw new Error('Failed to fetch products: ' + res.statusText);

    const products = await res.json();
    if (!Array.isArray(products)) throw new Error('Invalid response format');

    grid.innerHTML = '';

    if (products.length === 0) {
      grid.innerHTML = `<p style="text-align:center; font-size: 18px;">No Items listed yet, List to view items</p>`;
      return;
    }

    products.forEach(product => {
      const card = document.createElement('div');
      card.className = 'bid-item scale-hover';

      const imageDiv = document.createElement('div');
      imageDiv.className = 'item-image';
      imageDiv.style.backgroundImage = `url('http://localhost:3000${product.imageUrl}')`;

      const contentWrapper = document.createElement('div');
      contentWrapper.className = 'content-wrapper';

      const details = document.createElement('div');
      details.className = 'item-details';
      details.innerHTML = `
        <h3>${product.title}</h3>
        <p>Price: ₹${product.price}</p>
        <p>Condition: ${product.condition}</p>
      `;

      const controls = document.createElement('div');
      controls.className = 'item-controls';
      controls.innerHTML = `
        <button class="edit-btn" data-id="${product._id}"><i class="fas fa-edit"></i> Edit</button>
        <button class="delete-btn" data-id="${product._id}"><i class="fas fa-trash"></i> Delete</button>
      `;

      contentWrapper.appendChild(details);
      contentWrapper.appendChild(controls);

      card.appendChild(imageDiv);
      card.appendChild(contentWrapper);
      grid.appendChild(card);
    });

    // Delete handlers
    document.querySelectorAll('.delete-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const id = e.target.closest('button').dataset.id;
        if (confirm('Are you sure you want to delete this product?')) {
          const res = await fetch(`http://localhost:3000/api/products/${id}`, {
            method: 'DELETE'
          });
          if (res.ok) {
            location.reload();
          } else {
            alert('Failed to delete.');
          }
        }
      });
    });

    // Edit handlers
    document.querySelectorAll('.edit-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = e.target.closest('button').dataset.id;
        const newPrice = prompt('Enter new price:');
        if (newPrice) {
          fetch(`http://localhost:3000/api/products/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ price: parseInt(newPrice) })
          })
          .then(res => {
            if (res.ok) {
              location.reload();
            } else {
              alert('Update failed');
            }
          });
        }
      });
    });

  } catch (err) {
    console.error('Error loading products:', err);
    grid.innerHTML = '<p>Failed to load products.</p>';
  }
});
