document.addEventListener('DOMContentLoaded', function () {
  // Mobile Menu Toggle
  const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
  const navLinks = document.querySelector('.nav-links');

  mobileMenuToggle.addEventListener('click', function () {
    navLinks.classList.toggle('active');
    this.setAttribute('aria-expanded', navLinks.classList.contains('active'));
  });

  // Profile Dropdown in Navbar - Updated with mobile support
  const profileDropdown = document.querySelector('.navbar .profile-dropdown');
  const profileLink = document.getElementById('profile-link');

  profileLink.addEventListener('click', function (e) {
    if (window.innerWidth <= 768) {
      e.preventDefault();
      profileDropdown.classList.toggle('active');
      this.setAttribute('aria-expanded', profileDropdown.classList.contains('active'));
    }
  });

  // Close dropdowns when clicking outside
  document.addEventListener('click', function (e) {
    if (!e.target.closest('.navbar .profile-dropdown') && !e.target.closest('.dropdown')) {
      if (window.innerWidth <= 768) {
        profileDropdown.classList.remove('active');
        profileLink.setAttribute('aria-expanded', 'false');
      }
    }
  });

  // Footer Visibility with Throttle
  function throttle(func, limit = 100) {
    let inThrottle;
    return function () {
      const args = arguments;
      const context = this;
      if (!inThrottle) {
        func.apply(context, args);
        inThrottle = true;
        setTimeout(() => (inThrottle = false), limit);
      }
    };
  }

  function handleFooterVisibility() {
    const footer = document.querySelector('footer');
    const scrollPosition = window.innerHeight + window.scrollY;
    const documentHeight = document.documentElement.scrollHeight;
    const threshold = 50;

    if (scrollPosition >= documentHeight - threshold) {
      footer.style.bottom = '0';
    } else {
      footer.style.bottom = '-100%';
    }
  }

  window.addEventListener('scroll', throttle(handleFooterVisibility));
  window.addEventListener('resize', throttle(handleFooterVisibility));

  // Initialize footer position
  handleFooterVisibility();

  
  // Update greeting after login success
  function updateUserGreeting(username) {
    const authLink = document.getElementById('auth-link');
    authLink.textContent = `Hello, ${username}`;
    authLink.href = 'account.html';
    authLink.removeAttribute('onclick');
  }
  const logoutLink = document.getElementById('logout-link');
  if (logoutLink) {
    logoutLink.addEventListener('click', function(e) {
      e.preventDefault();
      if (confirm('Are you sure you want to log out?')) {
        window.location.href = 'index.html';
      }
    });
  }

  // Example usage (you can call this after validating login form)
  // updateUserGreeting("John");

  // Keyboard navigation for dropdowns
  const dropdowns = document.querySelectorAll('[class*="dropdown"]');

  dropdowns.forEach((dropdown) => {
    dropdown.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        const content = this.querySelector('[class*="content"]');
        const button = this.querySelector('a');

        if (window.innerWidth <= 768) {
          this.classList.remove('active');
          button.setAttribute('aria-expanded', 'false');
        } else {
          content.style.opacity = '0';
          content.style.visibility = 'hidden';
          content.style.transform = 'translateY(-10px)';
        }
        button.focus();
      }
    });
  });
});
