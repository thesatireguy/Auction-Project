document.addEventListener('DOMContentLoaded', function() {
    // Initialize shared components
    initSharedComponents();
    
    // Careers page specific animations
    animateCareersElements();
    
    // Setup notification form
    setupNotificationForm();
  });
  
  function initSharedComponents() {
    // Mobile Menu Toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileMenuToggle && navLinks) {
      mobileMenuToggle.addEventListener('click', function() {
        navLinks.classList.toggle('active');
        this.setAttribute('aria-expanded', navLinks.classList.contains('active'));
      });
    }
  
    // Profile Dropdown
    const profileDropdown = document.querySelector('.navbar .profile-dropdown');
    const profileLink = document.getElementById('profile-link');
    
    if (profileLink) {
      profileLink.addEventListener('click', function(e) {
        if (window.innerWidth <= 768) {
          e.preventDefault();
          profileDropdown.classList.toggle('active');
          this.setAttribute('aria-expanded', profileDropdown.classList.contains('active'));
        }
      });
    }
  
    
  }
  
  function animateCareersElements() {
    // Animate culture cards
    const cultureCards = document.querySelectorAll('.culture-card');
    cultureCards.forEach((card, index) => {
      card.style.opacity = '0';
      card.style.transform = 'translateY(20px)';
      card.style.transition = `opacity 0.6s ease ${index * 0.1}s, transform 0.6s ease ${index * 0.1}s`;
    });
  
    // Animate department cards
    const departmentCards = document.querySelectorAll('.department-card');
    departmentCards.forEach((card, index) => {
      card.style.opacity = '0';
      card.style.transform = 'translateY(20px)';
      card.style.transition = `opacity 0.6s ease ${index * 0.1 + 0.3}s, transform 0.6s ease ${index * 0.1 + 0.3}s`;
    });
  
    // Animate benefit items
    const benefitItems = document.querySelectorAll('.benefit-item');
    benefitItems.forEach((item, index) => {
      item.style.opacity = '0';
      item.style.transform = 'translateY(20px)';
      item.style.transition = `opacity 0.6s ease ${index * 0.1 + 0.6}s, transform 0.6s ease ${index * 0.1 + 0.6}s`;
    });
  
    // Observer to trigger animations when elements come into view
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }
      });
    }, { threshold: 0.1 });
  
    // Observe all animatable elements
    document.querySelectorAll('.culture-card, .department-card, .benefit-item').forEach(el => {
      observer.observe(el);
    });
  }
  
  function setupNotificationForm() {
    const notifyForm = document.querySelector('.notify-form');
    if (!notifyForm) return;
  
    const emailInput = notifyForm.querySelector('input');
    const submitBtn = notifyForm.querySelector('button');
  
    submitBtn.addEventListener('click', function(e) {
      e.preventDefault();
      
      if (!emailInput.value || !emailInput.value.includes('@')) {
        alert('Please enter a valid email address');
        return;
      }
  
      // In a real app, you would send this to your backend
      console.log('Notification request from:', emailInput.value);
      
      // Show confirmation
      submitBtn.innerHTML = '<i class="fas fa-check"></i> Success!';
      submitBtn.disabled = true;
      emailInput.disabled = true;
      
      setTimeout(() => {
        submitBtn.innerHTML = 'Notify Me';
        submitBtn.disabled = false;
        emailInput.disabled = false;
        emailInput.value = '';
      }, 3000);
    });
  }