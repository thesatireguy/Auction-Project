document.addEventListener('DOMContentLoaded', function () {
  // Mobile menu toggle
  const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
  const navLinks = document.querySelector('.nav-links');

  mobileMenuToggle.addEventListener('click', function () {
    navLinks.classList.toggle('active');
    this.setAttribute('aria-expanded', navLinks.classList.contains('active'));
  });

  // Profile dropdown
  const profileDropdown = document.querySelector('.profile-dropdown');
  const profileLink = document.getElementById('profile-link');

  profileLink?.addEventListener('click', function (e) {
    if (window.innerWidth <= 768) {
      e.preventDefault();
      profileDropdown.classList.toggle('active');
    }
  });

  document.addEventListener('click', function (e) {
    if (!e.target.closest('.profile-dropdown')) {
      profileDropdown.classList.remove('active');
    }
  });

  profileLink?.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      profileDropdown.classList.toggle('active');
    }
    if (e.key === 'Escape') {
      profileDropdown.classList.remove('active');
    }
  });

  // Logout functionality
  const logoutLink = document.getElementById('logout-link');
  logoutLink?.addEventListener('click', function (e) {
    e.preventDefault();
    if (confirm('Are you sure you want to log out?')) {
      localStorage.removeItem('user');
      window.location.href = 'index.html';
    }
  });

  // Load user data
  const storedUser = JSON.parse(localStorage.getItem('user'));
  let userData = {};

  if (storedUser && storedUser.username) {
    fetch(`http://localhost:3000/api/user/${storedUser.username}`)
      .then(response => response.json())
      .then(user => {
        userData = user;
        document.getElementById('first-name').value = user.first_name || '';
        document.getElementById('last-name').value = user.last_name || '';
        document.getElementById('user-name').value = user.username || '';
        document.getElementById('user-email').value = user.email || '';
        document.getElementById('user-phone').value = user.phone || '';
        document.getElementById('user-gender').value = user.gender || '';
        document.getElementById('user-city').value = user.city || '';
        document.getElementById('user-state').value = user.state || '';
        document.getElementById('user-country').value = user.country || '';
      })
      .catch(error => {
        console.error('Error fetching user data:', error);
      });
  } else {
    console.warn('No user is logged in');
  }

  // Edit Profile Button
  const editBtn = document.getElementById('edit-profile');
  let isEditing = false;

  editBtn?.addEventListener('click', function () {
    const inputs = document.querySelectorAll('.profile-details input');
    if (!isEditing) {
      inputs.forEach(input => {
        if (input.id !== 'user-name') {
          input.removeAttribute('readonly');
          input.classList.add('editable');
        }
      });
      editBtn.textContent = 'Save Changes';
      isEditing = true;
    } else {
      const updatedData = {
        first_name: document.getElementById('first-name').value.trim(),
        last_name: document.getElementById('last-name').value.trim(),
        email: document.getElementById('user-email').value.trim(),
        phone: document.getElementById('user-phone').value.trim(),
        gender: document.getElementById('user-gender').value.trim(),
        city: document.getElementById('user-city').value.trim(),
        state: document.getElementById('user-state').value.trim(),
        country: document.getElementById('user-country').value.trim()
      };

      // Update user in MongoDB
      fetch(`http://localhost:3000/api/user/${storedUser.username}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(updatedData)
      })
        .then(res => {
          if (!res.ok) throw new Error('Failed to update user');
          return res.json();
        })
        .then(result => {
          alert('Profile updated successfully!');
          // Lock fields again
          inputs.forEach(input => {
            input.setAttribute('readonly', true);
            input.classList.remove('editable');
          });
          editBtn.textContent = 'Edit Profile';
          isEditing = false;
        })
        .catch(error => {
          console.error('Update error:', error);
          alert('Failed to update profile.');
        });
    }
  });
});
