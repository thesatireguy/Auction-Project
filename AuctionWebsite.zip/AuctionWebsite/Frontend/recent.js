document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    mobileMenuToggle.addEventListener('click', function() {
      navLinks.classList.toggle('active');
      this.setAttribute('aria-expanded', navLinks.classList.contains('active'));
    });
  
    // Profile dropdown
    const profileDropdown = document.querySelector('.profile-dropdown');
    const profileLink = document.getElementById('profile-link');
    
    profileLink.addEventListener('click', function(e) {
      if (window.innerWidth <= 768) {
        e.preventDefault();
        profileDropdown.classList.toggle('active');
      }
    });
  
    // Remove item functionality
    document.querySelectorAll('.btn-remove').forEach(btn => {
      btn.addEventListener('click', function() {
        this.closest('.item-card').style.opacity = '0';
        setTimeout(() => {
          this.closest('.item-card').remove();
        }, 300);
      });
    });
  
    // Close dropdowns when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.profile-dropdown')) {
        profileDropdown.classList.remove('active');
      }
    });
  });