// Toggle mobile navbar
document.addEventListener("DOMContentLoaded", () => {
    const toggle = document.querySelector(".mobile-menu-toggle");
    const navLinks = document.querySelector(".nav-links");
    const profileDropdown = document.querySelector(".profile-dropdown");
  
    toggle.addEventListener("click", () => {
      navLinks.classList.toggle("active");
    });
  
    // Profile dropdown toggle (for mobile)
    profileDropdown.addEventListener("click", (e) => {
      e.stopPropagation();
      profileDropdown.classList.toggle("active");
    });
  
    // Close dropdowns on outside click
    document.addEventListener("click", () => {
      profileDropdown.classList.remove("active");
    });
  
    // Prevent dropdown close when clicking inside
    document.querySelectorAll('.dropdown').forEach(dropdown => {
      dropdown.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdown.classList.toggle('active');
      });
    });
  });
  