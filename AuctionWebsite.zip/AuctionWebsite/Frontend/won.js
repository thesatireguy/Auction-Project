// BIDS WON PAGE JS
document.addEventListener('DOMContentLoaded', function() {
    // View details functionality
    document.querySelectorAll('.won-action').forEach(btn => {
      btn.addEventListener('click', function() {
        // View details logic
      });
    });
  });