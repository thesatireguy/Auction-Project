document.addEventListener('DOMContentLoaded', () => {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const orderItemsContainer = document.getElementById('order-items');
    const totalPriceEl = document.getElementById('total-price');
    const placeOrderBtn = document.getElementById('place-order');
  
    function parsePrice(price) {
      if (typeof price === 'number') return price;
      if (typeof price === 'string') {
        return Number(price.replace(/[₹,]/g, '').trim()) || 0;
      }
      return 0;
    }
  
    function formatINR(amount) {
      return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
      }).format(amount);
    }
  
    function renderOrderSummary() {
      orderItemsContainer.innerHTML = '';
      let total = 0;
  
      cart.forEach(item => {
        const rawPrice = item.buyNowPrice || item.currentPrice || item.price || '0';
        const price = parsePrice(rawPrice);
        const quantity = item.quantity || 1;
        const itemTotal = price * quantity;
        total += itemTotal;
  
        const div = document.createElement('div');
        div.className = 'order-item';
        div.innerHTML = `
          <span>${item.name} × ${quantity}</span>
          <span>${formatINR(itemTotal)}</span>
        `;
        orderItemsContainer.appendChild(div);
      });
  
      totalPriceEl.textContent = formatINR(total);
    }
  
    placeOrderBtn.addEventListener('click', () => {
      const addressFields = ['name', 'street', 'city', 'state', 'zip', 'country'];
      const isAddressValid = addressFields.every(id => document.getElementById(id).value.trim() !== '');
      const selectedPayment = document.querySelector('input[name="payment"]:checked');
  
      if (!isAddressValid) {
        alert('Please fill in all address fields.');
        return;
      }
  
      if (!selectedPayment) {
        alert('Please select a payment method.');
        return;
      }
  
      alert('Order placed successfully!');
      localStorage.removeItem('cart');
      window.location.href = 'index.html'; // Or thank-you.html
    });
  
    renderOrderSummary();
  });
  