window.addEventListener('DOMContentLoaded', () => {
  const imageInput = document.getElementById('image');
  const preview = document.getElementById('imagePreview');
  const form = document.getElementById('sellForm');

  if (!imageInput || !form) return;

  imageInput.addEventListener('change', function () {
    preview.innerHTML = '';
    const file = this.files[0];
    if (file) {
      const img = document.createElement('img');
      img.src = URL.createObjectURL(file);
      preview.appendChild(img);
    }
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const userObj = JSON.parse(localStorage.getItem('user'));
    const username = userObj?.username;
    if (!username) return alert('User not found in localStorage');

    const formData = new FormData();
    formData.append('title', document.getElementById('title').value);
    formData.append('description', document.getElementById('description').value);
    formData.append('price', document.getElementById('price').value);
    formData.append('condition', document.getElementById('condition').value);
    formData.append('user', username);
    formData.append('image', imageInput.files[0]);

    try {
      const res = await fetch('http://localhost:3000/api/products', {
        method: 'POST',
        body: formData
      });

      const result = await res.json();
      if (!res.ok) throw new Error(result.message);

      alert('Product uploaded!');
      form.reset();
      preview.innerHTML = '';
    } catch (err) {
      console.error('Upload error:', err);
      alert('Upload failed');
    }
  });
});
