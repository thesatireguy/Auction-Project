document.addEventListener('DOMContentLoaded', () => {
    const authLink = document.getElementById('auth-link');
    const user = JSON.parse(localStorage.getItem('user'));
  
    if (authLink) {
      if (user) {
        authLink.textContent = `Hello, ${user.username}`;
        authLink.href = 'account.html';
      } else {
        authLink.textContent = 'Login';
        authLink.href = 'login.html';
      }
    }
  });
  const adminLinkEl = document.getElementById('adminLink');
  const isAdmin = localStorage.getItem('adminLoggedIn') === 'true';
  const isUser = localStorage.getItem('user'); // user is stored as JSON string

  if (isAdmin) {
    // Admin is logged in
    adminLinkEl.innerHTML = '<a href="#" onclick="adminLogout()">Logout (Admin)</a>';
  } else if (!isUser) {
    // No one is logged in, show Admin Login
    adminLinkEl.innerHTML = '<a href="admin-login.html">Admin Login</a>';
  }
  // If a normal user is logged in, hide admin login/logout completely

  function adminLogout() {
    localStorage.removeItem('adminLoggedIn');
    window.location.href = 'index.html';
  }