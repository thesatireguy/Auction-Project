document.getElementById('register-form').addEventListener('submit', async (e) => {
  e.preventDefault(); // Prevent form from submitting normally

  const first_name = document.getElementById('first_name').value.trim();
  const last_name = document.getElementById('last_name').value.trim();
  const username = document.getElementById('username').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const gender = document.getElementById('gender').value;
  const city = document.getElementById('city').value.trim();
  const state = document.getElementById('state').value.trim();
  const country = document.getElementById('country').value.trim();
  const phone = document.getElementById('phone').value.trim();

  const user = {
    first_name: first_name,
    last_name: last_name,
    email: email,
    username: username,
    phone: phone,
    city: city,
    state: state,
    country: country,
    gender: gender,
    password: password // In a real app, you'd hash the password before saving it
  };

  // Save to localStorage
  localStorage.setItem('user', JSON.stringify(user));

  try {
    const response = await fetch('http://localhost:3000/api/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        first_name,
        last_name,
        username,
        email,
        password,
        gender,
        city,
        state,
        country,
        phone
      })
    });

    const result = await response.json();
    const agreeCheckbox = document.getElementById('agree');

    const messageDiv = document.getElementById('message');

    if (!agreeCheckbox.checked) {
    messageDiv.textContent = 'You must agree to the Terms & Conditions and Privacy Policy.';
    messageDiv.style.color = 'red';
    return;
  }

    if (response.ok) {
      messageDiv.textContent = 'Registration successful! Redirecting to login...';
      messageDiv.style.color = 'green';
      setTimeout(() => {
        window.location.href = 'login.html';
      }, 2000);
    } else {
      messageDiv.textContent = result.error || 'Registration failed';
      messageDiv.style.color = 'red';
    }
  } catch (err) {
    document.getElementById('message').textContent = 'Server error. Please try again later.';
    document.getElementById('message').style.color = 'red';
    console.error(err);
  }
});
