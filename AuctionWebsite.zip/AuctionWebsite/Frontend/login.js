document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('login-form').addEventListener('submit', async function (e) {
    e.preventDefault();

    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;

    try {
      const response = await fetch('http://127.0.0.1:3000/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      

      const data = await response.json();
      console.log(data); // ADD THIS LINE to debug

      const msgBox = document.getElementById('login-message');

      if (response.ok) {

       // Example after login success
       localStorage.setItem('user', JSON.stringify({
        id: data.user._id,
        username: data.user.username,
        email: data.user.email // <-- Add this line
      }));

      localStorage.setItem('username', data.user.username);      

        msgBox.innerText = 'Login successful! Redirecting...';
        msgBox.style.color = 'green';

        setTimeout(() => {
          window.location.href = 'index.html';
        }, 1000);
      } else {
        msgBox.innerText = data.message || 'Login failed.';
        msgBox.style.color = 'red';
      }
    } catch (err) {
      console.error(err);
      document.getElementById('login-message').innerText = 'Network error.';
    }
  });
});
