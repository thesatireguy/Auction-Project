document.addEventListener('DOMContentLoaded', () => {
  const cartContainer = document.getElementById('cart-items');
  const cartTotal = document.getElementById('cart-total');
  const checkoutBtn = document.getElementById('checkoutBtn');

  let cart = JSON.parse(localStorage.getItem('cart')) || [];

  function formatINR(amount) {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  }

  function renderCart() {
    cartContainer.innerHTML = '';

    if (!cart.length) {
      cartContainer.innerHTML = '<p>Your cart is empty.</p>';
      cartTotal.textContent = 'Total: ₹0';
      checkoutBtn.textContent = 'Please log in first';
      checkoutBtn.disabled = true;
      return;
    }

    let total = 0;

    cart.forEach((item, index) => {
      // Ensure the item has a valid price and quantity
      const price = item.price || 0;
      const quantity = item.quantity || 1; // Default to 1 if quantity is missing
      const itemTotal = price * quantity;
      total += itemTotal;

      const itemDiv = document.createElement('div');
      itemDiv.className = 'cart-item';
      itemDiv.innerHTML = `
        <div class="item-details">
          <h4>${item.title}</h4>
          <p>${item.description || 'No description available.'}</p>
        </div>
        <div class="item-price">${formatINR(itemTotal)}</div>
        <div class="cart-actions">
          <input type="number" min="1" value="${quantity}" data-index="${index}" />
          <button class="remove-btn" data-index="${index}">Remove</button>
        </div>
      `;

      cartContainer.appendChild(itemDiv);
    });

    cartTotal.textContent = `Total: ${formatINR(total)}`;

    // Check if user is logged in to enable checkout
    const userObj = JSON.parse(localStorage.getItem('user'));
    if (!userObj) {
      checkoutBtn.textContent = 'Please log in first';
      checkoutBtn.disabled = true;
    } else {
      checkoutBtn.textContent = 'Proceed to Checkout';
      checkoutBtn.disabled = false;
    }
  }

  // Update cart when item is removed
  cartContainer.addEventListener('click', (e) => {
    if (e.target.classList.contains('remove-btn')) {
      const index = e.target.dataset.index;
      cart.splice(index, 1);  // Remove item from cart array
      localStorage.setItem('cart', JSON.stringify(cart));  // Update localStorage
      renderCart();  // Re-render the cart
    }
  });

  // Update cart when quantity is changed
  cartContainer.addEventListener('input', (e) => {
    if (e.target.type === 'number') {
      const index = e.target.dataset.index;
      const value = parseInt(e.target.value);
      if (!isNaN(value) && value > 0) {
        cart[index].quantity = value;  // Update quantity
        localStorage.setItem('cart', JSON.stringify(cart));  // Update localStorage
        renderCart();  // Re-render the cart
      }
    }
  });

  // Handle Checkout button click
  checkoutBtn.addEventListener('click', () => {
    if (checkoutBtn.textContent === 'Please log in first') {
      alert('Please log in to proceed with checkout.');
      window.location.href = 'login.html';  // Redirect to login page if not logged in
    } else {
      window.location.href = 'checkout.html';  // Proceed to checkout if logged in
    }
  });

  renderCart();  // Initial render of the cart
});
