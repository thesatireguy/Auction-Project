document.addEventListener('DOMContentLoaded', function() {
    // Mobile Menu Toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    mobileMenuToggle.addEventListener('click', function() {
      navLinks.classList.toggle('active');
      this.setAttribute('aria-expanded', navLinks.classList.contains('active'));
    });
  
    // Profile Dropdown
    const profileDropdown = document.querySelector('.profile-dropdown');
    const profileLink = document.getElementById('profile-link');
    
    profileLink.addEventListener('click', function(e) {
      if (window.innerWidth <= 768) {
        e.preventDefault();
        profileDropdown.classList.toggle('active');
      }
    });
  
    // Watch Button Toggle
    document.querySelectorAll('.btn-watch').forEach(btn => {
      btn.addEventListener('click', function() {
        this.classList.toggle('active');
        const itemTitle = this.closest('.watchlist-item').querySelector('.item-title').textContent;
        const status = this.classList.contains('active') ? 'watching' : 'removed from watchlist';
        console.log(`${itemTitle} ${status}`);
      });
    });
  
    // Select All Button
    document.querySelector('.btn-select-all').addEventListener('click', function() {
      document.querySelectorAll('.item-checkbox input').forEach(checkbox => {
        checkbox.checked = true;
      });
      console.log('All items selected');
    });
  
    // Clear Selection Button
    document.querySelector('.btn-clear').addEventListener('click', function() {
      document.querySelectorAll('.item-checkbox input').forEach(checkbox => {
        checkbox.checked = false;
      });
      console.log('Selection cleared');
    });
  
    // Close dropdowns when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.profile-dropdown')) {
        profileDropdown.classList.remove('active');
      }
    });
  
    // Logout functionality
    const logoutLink = document.getElementById('logout-link');
    if (logoutLink) {
      logoutLink.addEventListener('click', function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to log out?')) {
          window.location.href = 'index.html';
        }
      });
    }
  });