document.addEventListener('DOMContentLoaded', function() {
    // Initialize shared components
    initSharedComponents();
    
    // About page specific animations
    animateAboutSections();
  });
  
  function initSharedComponents() {
    // Mobile Menu Toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileMenuToggle && navLinks) {
      mobileMenuToggle.addEventListener('click', function() {
        navLinks.classList.toggle('active');
        this.setAttribute('aria-expanded', navLinks.classList.contains('active'));
      });
    }
  
    // Profile Dropdown
    const profileDropdown = document.querySelector('.navbar .profile-dropdown');
    const profileLink = document.getElementById('profile-link');
    
    if (profileLink) {
      profileLink.addEventListener('click', function(e) {
        if (window.innerWidth <= 768) {
          e.preventDefault();
          profileDropdown.classList.toggle('active');
          this.setAttribute('aria-expanded', profileDropdown.classList.contains('active'));
        }
      });
    }
  
  
  function animateAboutSections() {
    const sections = document.querySelectorAll('.about-section');
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }
      });
    }, { threshold: 0.1 });
    
    sections.forEach(section => {
      section.style.opacity = '0';
      section.style.transform = 'translateY(20px)';
      section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
      observer.observe(section);
    });
    
    // Animate images with slight delay
    const images = document.querySelectorAll('.about-image img');
    images.forEach((img, index) => {
      img.style.opacity = '0';
      img.style.transform = 'scale(0.95)';
      img.style.transition = `opacity 0.6s ease ${index * 0.2}s, transform 0.6s ease ${index * 0.2}s`;
      
      const imgObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'scale(1)';
          }
        });
      }, { threshold: 0.1 });
      
      imgObserver.observe(img);
    });
  }}