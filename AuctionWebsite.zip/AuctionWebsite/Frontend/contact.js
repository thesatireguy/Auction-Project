document.addEventListener('DOMContentLoaded', function() {
    // ===== MOBILE MENU TOGGLE =====
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    mobileMenuToggle.addEventListener('click', function() {
      navLinks.classList.toggle('active');
      this.setAttribute('aria-expanded', navLinks.classList.contains('active'));
    });
  
    // ===== DROPDOWNS =====
    const dropdowns = document.querySelectorAll('.dropdown, .profile-dropdown');
    
    // Desktop hover behavior
    dropdowns.forEach(dropdown => {
      dropdown.addEventListener('mouseenter', function() {
        if (window.innerWidth > 768) {
          const content = this.querySelector('.dropdown-content, .profile-dropdown-content');
          content.style.opacity = '1';
          content.style.visibility = 'visible';
          content.style.transform = 'translateY(0)';
        }
      });
      
      dropdown.addEventListener('mouseleave', function() {
        if (window.innerWidth > 768) {
          const content = this.querySelector('.dropdown-content, .profile-dropdown-content');
          content.style.opacity = '0';
          content.style.visibility = 'hidden';
          content.style.transform = 'translateY(-10px)';
        }
      });
    });
  
    // Mobile click behavior
    dropdowns.forEach(dropdown => {
      const trigger = dropdown.querySelector('a');
      trigger.addEventListener('click', function(e) {
        if (window.innerWidth <= 768) {
          e.preventDefault();
          dropdown.classList.toggle('active');
          const content = dropdown.querySelector('.dropdown-content, .profile-dropdown-content');
          if (dropdown.classList.contains('active')) {
            content.style.display = 'block';
          } else {
            content.style.display = 'none';
          }
        }
      });
    });
  
    // ===== CLOSE DROPDOWNS WHEN CLICKING OUTSIDE =====
    document.addEventListener('click', function(e) {
      if (window.innerWidth <= 768) {
        dropdowns.forEach(dropdown => {
          if (!dropdown.contains(e.target) && !e.target.classList.contains('mobile-menu-toggle')) {
            dropdown.classList.remove('active');
            const content = dropdown.querySelector('.dropdown-content, .profile-dropdown-content');
            content.style.display = 'none';
          }
        });
        
        if (!e.target.closest('.mobile-menu-toggle') && !e.target.closest('.nav-links')) {
          navLinks.classList.remove('active');
          mobileMenuToggle.setAttribute('aria-expanded', 'false');
        }
      }
    });
  
    // ===== SCALE HOVER EFFECTS =====
    document.querySelectorAll('.scale-hover').forEach(element => {
      element.addEventListener('mouseenter', function() {
        this.style.transform = 'scale(1.05)';
      });
      element.addEventListener('mouseleave', function() {
        this.style.transform = 'scale(1)';
      });
    });
  
    // ===== MODAL FUNCTIONALITY =====
   
    // ===== PROFILE LINK UPDATE (FOR LOGGED IN USERS) =====
    function updateUserGreeting(username) {
      const authLink = document.getElementById('auth-link');
      if (authLink) {
        authLink.textContent = `Hello, ${username}`;
        authLink.href = 'account.html';
      }
    }
    // Example: updateUserGreeting("John");
  });