document.addEventListener('DOMContentLoaded', () => {
  const img = document.getElementById('main-image');
  const zoomBox = document.getElementById('zoom-box');

  if (img && zoomBox) {
    img.addEventListener('mouseenter', () => {
      zoomBox.style.display = 'block';
      zoomBox.style.backgroundImage = `url(${img.src})`;
    });

    img.addEventListener('mousemove', (e) => {
      const rect = img.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      const zoomWidth = zoomBox.offsetWidth;
      const zoomHeight = zoomBox.offsetHeight;
      const xPos = Math.max(0, Math.min(x - zoomWidth / 2, rect.width - zoomWidth));
      const yPos = Math.max(0, Math.min(y - zoomHeight / 2, rect.height - zoomHeight));

      zoomBox.style.left = `${xPos}px`;
      zoomBox.style.top = `${yPos}px`;

      const xPercent = (x / rect.width) * 100;
      const yPercent = (y / rect.height) * 100;
      zoomBox.style.backgroundPosition = `${xPercent}% ${yPercent}%`;
    });

    img.addEventListener('mouseleave', () => {
      zoomBox.style.display = 'none';
    });
  }

  // Buy Now logic
  const buyNowBtn = document.getElementById('buyNowBtn');
  if (buyNowBtn) {
    buyNowBtn.addEventListener('click', () => {
      const infoElements = document.querySelectorAll('.info');
      const name = document.querySelector('.details-section h2')?.textContent.trim();
      const image = document.querySelector('.product-image')?.src || '';

      const product = {
        name,
        seller: '',
        condition: '',
        description: '',
        currentPrice: '',
        buyNowPrice: 0,
        image,
        quantity: 1
      };

      infoElements.forEach(div => {
        const label = div.querySelector('strong')?.textContent.toLowerCase();
        const value = div.textContent.replace(div.querySelector('strong')?.textContent, '').trim();

        if (label.includes('seller')) product.seller = value;
        else if (label.includes('condition')) product.condition = value;
        else if (label.includes('description')) product.description = value;
        else if (label.includes('current price')) product.currentPrice = value;
        else if (label.includes('buy now price')) {
          const num = value.replace(/[^\d.]/g, '');
          product.buyNowPrice = parseFloat(num) || 0;
        }
      });

      // Add to existing cart
      const cart = JSON.parse(localStorage.getItem('cart')) || [];
      cart.push(product);
      localStorage.setItem('cart', JSON.stringify(cart));

      window.location.href = 'cart.html';
    });
  }
});
