document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    mobileMenuToggle.addEventListener('click', function() {
      navLinks.classList.toggle('active');
      this.setAttribute('aria-expanded', navLinks.classList.contains('active'));
    });
  
    // Profile dropdown
    const profileDropdown = document.querySelector('.profile-dropdown');
    const profileLink = document.getElementById('profile-link');
    
    profileLink.addEventListener('click', function(e) {
      if (window.innerWidth <= 768) {
        e.preventDefault();
        profileDropdown.classList.toggle('active');
      }
    });
  
    // Close dropdowns when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.profile-dropdown')) {
        profileDropdown.classList.remove('active');
      }
    });
  
    // Bid actions
    document.querySelectorAll('.bid-action').forEach(btn => {
      btn.addEventListener('click', function() {
        const itemTitle = this.closest('.bid-item').querySelector('.item-title').textContent;
        alert(`Bid increase form would open for: ${itemTitle}`);
      });
    });
  
    // Logout functionality
    const logoutLink = document.getElementById('logout-link');
    if (logoutLink) {
      logoutLink.addEventListener('click', function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to log out?')) {
          // In a real app, you would handle logout here
          window.location.href = 'index.html';
        }
      });
    }
  });